<?php
class DATABASE_CONFIG {

	public $default = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => 'localhost',
		'login' => 'prodigyn_smartfl',
		'password' => '-l,[QiSR+Mgt',
		'database' => 'prodigyn_smartflow',
	);
}