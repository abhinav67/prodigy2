
	 <script>
        $(document).ready(function() { $("#CustomerCityId").select2(); });
    </script>
