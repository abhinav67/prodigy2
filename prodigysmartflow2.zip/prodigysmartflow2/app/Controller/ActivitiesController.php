<?php
App::uses('AppController', 'Controller');
/**
 * Activities Controller
 *
 * @property Activity $Activity
 * @property PaginatorComponent $Paginator
 */
class ActivitiesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Activity->recursive = 0;
		$this->set('activities', $this->Paginator->paginate());
		$this->loadModel('ActivityType');
		$atypes=$this->ActivityType->find('list');
		$this->set(compact('atypes'));
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Activity->exists($id)) {
			throw new NotFoundException(__('Invalid activity'));
		}
		$options = array('conditions' => array('Activity.' . $this->Activity->primaryKey => $id));
		$this->set('activity', $this->Activity->find('first', $options));
		$this->loadModel('ActivityType');
		$atypes=$this->ActivityType->find('list');
		$this->set(compact('atypes'));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
if(!isset($_GET['select_month']) && !isset($_GET['year']) && !isset($_GET['ethnicity']))
		{
			return $this->redirect(array('action' => 'selectmonth'));
		}
		else
		{
			$month=$_GET['month'];
			$year=$_GET['year'];
			$ethnicity=$_GET['ethnicity'];
			$days=$_GET['days'];
		}

		//$days=cal_days_in_month(CAL_GREGORIAN, $month, $year);
		if ($this->request->is('post')) {
			$this->Activity->create();
			if ($this->Activity->saveAll($this->request->data['Activity'])) {
				$this->Session->setFlash(__('The activity has been saved.'), 'default', array('class' => 'alert alert-success'));
				//pr ($this->data);
				return $this->redirect(array('action' => 'index'));
			} else {
				//pr ($this->data);
				$this->Session->setFlash(__('The activity could not be saved. Please, try again.'), 'default', array('class' => 'alert alert-danger'));
			}
		}
		$this->loadModel('ActivityType');
		$atypes=$this->ActivityType->find('list');
		$this->set(compact('atypes','month','year','ethnicity','days'));

	}

	public function selectmonth()
	{

		$dt=date("Y");
		$dt1=Date('Y',strtotime("+1 year"));
		$dt2=Date('Y',strtotime("-1 year"));
		
		

		$this->loadModel('CustomerEthnicity');
		$etypes=$this->CustomerEthnicity->find('list');
		$this->set(compact('etypes','dt','dt1','dt2'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Activity->exists($id)) {
			throw new NotFoundException(__('Invalid activity'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Activity->save($this->request->data)) {
				$this->Session->setFlash(__('The activity has been saved.'), 'default', array('class' => 'alert alert-success'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The activity could not be saved. Please, try again.'), 'default', array('class' => 'alert alert-danger'));
			}
		} else {
			$options = array('conditions' => array('Activity.' . $this->Activity->primaryKey => $id));
			$this->request->data = $this->Activity->find('first', $options);
		}
		$this->loadModel('ActivityType');
		$atypes=$this->ActivityType->find('list');
		$this->set(compact('atypes'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Activity->id = $id;
		if (!$this->Activity->exists()) {
			throw new NotFoundException(__('Invalid activity'));
		}
		$this->request->onlyAllow('post', 'delete');
		if ($this->Activity->delete()) {
			$this->Session->setFlash(__('The activity has been deleted.'), 'default', array('class' => 'alert alert-success'));
		} else {
			$this->Session->setFlash(__('The activity could not be deleted. Please, try again.'), 'default', array('class' => 'alert alert-danger'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}
