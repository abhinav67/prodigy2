<?php
class AppController extends Controller {
      public $components = array(
        'Acl','Auth','Session');

public function beforeFilter() {

	
  
$this->Auth->loginError = "Wrong credentials";
$this->Auth->authError = "This part of the website is protected.";
$this->Auth->loginAction = array("controller" => "users", "action" => "login");
$this->Auth->loginRedirect = array('controller' => 'Dashboards','action' => 'index');
$this->Auth->logoutRedirect = array("controller" => "users", "action" => "login");
     
    $this->layout = 'bootstrap';

$this->Auth->deny();
$this->Auth->allow('display');
  
    $user1 = $this->Session->read("Auth.User");
      $user=$user1['username'];
      // pr($user['username']);
      $this->set(compact('user'));
    }
  
  
}
