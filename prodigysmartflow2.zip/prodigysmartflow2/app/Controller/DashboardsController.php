<?php
App::uses('AppController', 'Controller');
/**
 * Activities Controller
 *
 * @property Activity $Activity
 * @property PaginatorComponent $Paginator
 */
class DashboardsController extends AppController {


	var $helpers = array('Html', 'Form','Csv','Js'); 



public function index() {

	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);

	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	$this->set(compact('abi'));
	$this->set('inst',$this->Insurance->find('count'));

			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}


public function dashboard_participants(){
	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);

	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	$this->set(compact('abi'));
	$this->set('inst',$this->Insurance->find('count'));

			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}

public function dashboard_activities(){
	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);

	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	$this->set(compact('abi'));
	$this->set('inst',$this->Insurance->find('count'));

			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Activity');
	$activities=$this->Activity->find('all');
	$this->loadModel('ActivityType');
	$at=$this->ActivityType->find('list');

	for ($a=0; count($activities)> $a; $a++){

$rows[]= '{"id":'.$activities[$a]['Activity']['id'].', "title":"'.$at[$activities[$a]['Activity']['activity_type_id1']].'", "start":"'.$activities[$a]['Activity']['date']."T".$activities[$a]['Activity']['time'].'"}';
$rows1[]= '{"id":'.$activities[$a]['Activity']['id'].', "title":"'.$at[$activities[$a]['Activity']['activity_type_id2']].'", "start":"'.$activities[$a]['Activity']['date']."T".$activities[$a]['Activity']['time1'].'"}';
}

// convert the array to a string.
if ($rows){
$convertojson = implode(",", $rows).",".implode(",",$rows1);
}

// pass the string to the json variable. this will then be passed  and printed to the javascript code.
$this->set('json',"[".$convertojson."]"); 


	

	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}

public function dashboard_daytrack(){
	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);

	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	$itypes=$this->Insurance->find('list');
	$this->set(compact('abi','itypes'));
	//pr($itypes);
	$this->set('inst',$this->Insurance->find('count'));

			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}

public function dashboard_daytrack1(){
	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);

	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	
	$this->set(compact('abi'));
	$this->set('inst',$this->Insurance->find('count'));

			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}
	
		public function dashboard_daytrack2(){
	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);

	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	$itypes=$this->Insurance->find('list');
	$this->set(compact('abi','itypes'));
	//pr($itypes);
	$this->set('inst',$this->Insurance->find('count'));

			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}


public function print_participants(){
	if(!isset($_GET['datedaytrack']) && !isset($_GET['insure']) && !isset($_GET['shift']))
		{
			return $this->redirect(array('action' => 'dashboard_daytrack'));
		}
		else
		{
			$date=$_GET['datedaytrack'];
			$insure=$_GET['insure'];
			$shift=$_GET['shift'];
			//$days=$_GET['days'];
		}

	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman','date','insure','shift'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);
   		$dt = strtotime($date);

		$day = date("l", $dt);

		$sh  = array("am","pm");
		$key     = array_search($shift,$sh);
		$shiftclean = $sh[$key]; //if not, first one will be set automatically. smart enuf :)
		
	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	$itypes=$this->Insurance->find('list');
	$ins_id=$this->Insurance->find('first',array('conditions'=>array('Insurance.name'=>"$insure"),'fields'=>'Insurance.id','recursive'=>0));

	$get_itypes=array(
		'conditions'=> array('AND'=>array(
									array('Customer.insurance_id'=>$ins_id['Insurance']['id']),
									array("{$day}"."_"."{$shiftclean}" => 1,'Customer.status_code_id' =>  '')
									)),
		'recursive'=>0
		);
	$selected_part=$this->Customer->find('list',$get_itypes);
	//pr($selected_part);
	$customers=$this->Customer->find('list');
	$this->set(compact('abi','itypes','customers','selected_part'));

    
    
	$this->set('inst',$this->Insurance->find('count'));
	
			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}


	public function download()
{
    $this->set('customers', $this->Customer->find('all',array('fields'=>array('first_name'))));
    
    $this->layout = null;
   $this->autoLayout = false;
  Configure::write('debug', '0');
}


public function dashboard_transport(){
	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);

	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	$this->set(compact('abi'));
	$this->set('inst',$this->Insurance->find('count'));

			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}

public function dashboard_others(){
	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);

	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	$this->set(compact('abi'));
	$this->set('inst',$this->Insurance->find('count'));

			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}



	public function dashboard_settings(){
	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);

	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	$this->set(compact('abi'));
	$this->set('inst',$this->Insurance->find('count'));

			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}


	public function dashboard_employee(){
	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);

	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	$this->set(compact('abi'));
	$this->set('inst',$this->Insurance->find('count'));

			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}


public function dashboard_vendors(){
	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);

	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	$this->set(compact('abi'));
	$this->set('inst',$this->Insurance->find('count'));

			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}


	public function dashboard_attendance(){
	$wr=$this->webroot;
	$this->set(compact('wr'));

	$this->loadModel('BillingRecord');
	$lastBill=$this->BillingRecord->find('first',array( 'order' => array('date DESC')));
	$this->set(compact('lastBill'));
	

	$this->loadModel('CustomerAttendance');
	$raman=$this->CustomerAttendance->find('all',array( 'order' => array('date DESC'),'limit'=>7));
	$this->set(compact('raman'));
	
	$expectedccustomers=array();
	$i=0;
	foreach ($raman	 as $ram ) {
		$this->loadModel('Customer');
		$day= date("l",strtotime($ram['CustomerAttendance']['date']));
		$gettodaycustomers=array(
      	'conditions' => array(
      			array(
      			'OR'=>array(
      			array("{$day}"."_"."am" => 1),
      			array("{$day}"."_"."pm" => 1)
      			)
      			),
      			'Customer.status_code_id' =>  ''), //array of conditions
      	'fields' => array('id'),
      	'recursive' => 0
   		);
   		$expectedccustomers[$i]=$this->Customer->find('count',$gettodaycustomers);
   		$i++;
	}
   		//$expectedcustomers[$i]=array($this->Customer->find('count',$gettodaycustomers));
   		//pr($expectedcustomers);
   		$this->set('expectedccustomers',$expectedccustomers);

	$this->loadModel('Insurance');
	$abi=$this->Insurance->find('all',array());
	$this->set(compact('abi'));
	$this->set('inst',$this->Insurance->find('count'));

			$yymmdd=date("ymd");
		$NewDate=Date('ymd', strtotime("+60 days"));
		$plusDate=Date('ymd', strtotime("+30 days"));
		$OldDate=Date('ymd', strtotime("-30 days"));
	
	$this->loadModel('Todo');
	$this->set('sur',$this->Todo->find('all',array(
'conditions' => 
			array('Todo.date >= ' => $yymmdd,   //billing from date
			   	  'Todo.date <= ' => $NewDate		//billing till date
				),
		'order'=>array('date ASC'),'limit'=>4)));


	$this->loadModel('Customer');
	$this->set('cnt',$this->Customer->find('count'));
	$this->set('mcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"M"))));
	$this->set('fcount',$this->Customer->find('count',array('conditions'=>array("client_sex"=>"F"))));
	
	
	$this->loadModel('CustomerEthnicity');
	$eths=$this->CustomerEthnicity->find('all',array());
	$this->set(compact('eths'));

	$this->loadModel('Physician');
	$phys=$this->Physician->find('all',array());
	$this->set(compact('phys'));


	$this->loadModel('Event');
	$this->set('evt',$this->Event->find('all'));
	$this->set('evt1',$this->Event->find('all',array( 'conditions' => 
			array('Event.event_date >= ' => $yymmdd,   //billing from date
			   	  'Event.event_date <= ' => $NewDate   //billing till date
				),'order'=>array('Event.event_date ASC'),
			'order'=>array('Event.event_date ASC'),'limit'=>4)));

	$this->set('bday',$this->Customer->find('all',array('conditions' =>array("OR"=>array(array('MONTH(Customer.date_of_birth)' => date('m')),array('MONTH(Customer.date_of_birth)' => date('m', strtotime('+30 days'))))) ,
			'limit' => 4,'order'=>'DAYOFYEAR(Customer.date_of_birth) ASC', 'fields'=>array('birthday','first_name','last_name'),'recursive'=>0 )));

	$this->set('autho',$this->Customer->find('all',
		array( 'conditions' => 
			array('Customer.auth_expiry >= ' => $yymmdd,   //billing from date
			   	  'Customer.auth_expiry <= ' => $NewDate		//billing till date
				),'order'=>array('Customer.auth_expiry ASC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
	
$this->set('lautho',$this->Customer->find('all',array(
 'conditions' => 
			array('Customer.auth_expiry >= ' => $OldDate,   //billing from date
			   	  'Customer.auth_expiry <= ' => $yymmdd		//billing till date
				),'order'=>array('Customer.auth_expiry DESC'),
			'limit' => 4, 'fields'=>array('auth_expiry','precertref','first_name','last_name','raman'),'recursive'=>0 )));
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


	}


public function graphr ()
	{
$this->loadModel('Customer');


$this->set('ageM',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"),'conditions'=>array('Customer.client_sex'=>'M'))));

$this->set('ageF',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"),'conditions'=>array('Customer.client_sex'=>'F'))));

	}

	public function agereports ()
	{
			$wr=$this->webroot;
	$this->set(compact('wr'));

$this->loadModel('Customer');
$this->set('age',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"))));


$this->set('ageM',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"),'conditions'=>array('Customer.client_sex'=>'M'))));

$this->set('ageF',$this->Customer->find('list',array("recursive"=>0,'fields'=>array("Customer.first_name","Customer.age"),'conditions'=>array('Customer.client_sex'=>'F'))));

	}


}
