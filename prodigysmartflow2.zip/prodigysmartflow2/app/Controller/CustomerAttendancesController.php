<?php
App::uses('AppController', 'Controller');
/**
 * CustomerAttendances Controller
 *
 * @property CustomerAttendance $CustomerAttendance
 * @property PaginatorComponent $Paginator
 */
class CustomerAttendancesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
	$this->set('title_for_layout', 'Participant Attendances');
		$correctcname=$this->params['controller'];
		//pr($this->params['controller']);
		$cname=strtolower($correctcname);
		if ($cname=="customerattendances")
		{
			$this->redirect("/customer_attendances");
		}
		$options=array('date');
		$r=1;
		include 'ramansearch.php';
		//pr($customerAttendance);
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
	//$this->set('title_for_layout', 'View Participants Attendance');
		if (!$this->CustomerAttendance->exists($id)) {
			throw new NotFoundException(__('Invalid customer attendance'));
		}
		$options = array('conditions' => array('CustomerAttendance.' . $this->CustomerAttendance->primaryKey => $id));
		$this->set('customerAttendance', $this->CustomerAttendance->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
	//$this->set('title_for_layout', 'Add Participants Attendance');
		if(!isset($_GET['select_date']) && !isset($_GET['shift']))
		{
			return $this->redirect(array('action' => 'selectday'));
		}
		else
		{
			$date=$_GET['select_date'];
			$shift=$_GET['shift'];
		}
		if ($this->request->is('post')) {
			$this->CustomerAttendance->create();
			if ($this->CustomerAttendance->save($this->request->data)) {
				$this->Session->setFlash(__('The customer attendance has been saved.'), 'default', array('class' => 'alert alert-success'));
				return $this->redirect(array('action' => 'index'));
			} else {
				//$this->Session->setFlash(__('The customer attendance could not be saved. Please, try again.'), 'default', array('class' => 'alert alert-danger'));
				  $this->Session->setFlash(__('The customer attendance has already been created, please edit to make changes.'), 'default', array('class' => 'alert alert-danger'));
				  return $this->redirect(array('action' => 'index'));
			}
		}
		$customers = $this->CustomerAttendance->Customer->find('list',array('conditions' => array('Customer.status_code_id' =>  '')));
		asort($customers);
		$this->set(compact('customers'));
		$this->loadModel('Customer');

		$dt = strtotime($date);

		$day = date("l", $dt);

		$sh  = array("am","pm");
		$key     = array_search($shift,$sh);
		$shiftclean = $sh[$key]; //if not, first one will be set automatically. smart enuf :)

		$gettodaycustomers=array(
			'conditions' => array("{$day}"."_"."{$shiftclean}" => 1,'Customer.status_code_id' =>  ''), //array of conditions
			'fields' => array('id'),
			'recursive' => 0
		);
		//pr($gettodaycustomers);
		$expectedcustomers=$this->Customer->find('list',$gettodaycustomers);
		asort($expectedcustomers);
		//pr($expectedcustomers);
		$this->set('expectedcustomers',$expectedcustomers);
		$this->set('dateinurl',$dt);
		$this->set('shift',$shiftclean);
		$this->set('day',$day);
		
		$this->loadModel('Companies');
		$comp = $this->Companies->find('all');
		$this->set('comp', $comp);
	}
		public function recent_attendance() {
		$this->loadModel('Companies');
		$comp = $this->Companies->find('all');
		$this->set('comp',$comp);
		//pr($comp);
		$date=date('M-d-Y');
			$shift=$_GET['shift'];

		$sh  = array($comp[0]['Companies']['pm'],$comp[0]['Companies']['am'],);
		$key     = array_search($shift,$sh);
		$shiftclean = $sh[$key]; //if not, first one will be set automatically. smart enuf :)
		//$both=$comp[0]['Companies']['shift'];
		$this->set('shiftclean',$shiftclean);

		/* $shh  = array($comp[0]['Companies']['am'],);
		$keyy     = array_search($shift,$shh);
		$shiftclean1 = $sh[$keyy]; //if not, first one will be set automatically. smart enuf :)
		//$both=$comp[0]['Companies']['shift'];
		$this->set('shiftclean1',$shiftclean1); */
		
		
		//pr($shift);
			//pr($sh);
			//pr($key);
			//pr($shiftclean);
			$chk=$this->CustomerAttendance->findAllByDateAndShift($date,'am');
			$chk1=$this->CustomerAttendance->findAllByDateAndShift($date,'pm');
			$chk3=$this->CustomerAttendance->findAllByDateAndShift($date,$comp[0]['Companies']['am']);
			$chk4=$this->CustomerAttendance->findAllByDateAndShift($date,$comp[0]['Companies']['pm']);

			//pr($chk2);
		/*	if($shiftclean==$comp[0]['Companies']['pm'])
				{
			if($chk1){
					$rurl11="/customer_Attendances/index";
					return $this->redirect("{$rurl11}");
			}
		}
		if($shiftclean==$comp[0]['Companies']['am'])
				{
			if($chk){
				$rurl2="/customer_Attendances/index";
					return $this->redirect("{$rurl2}");
			}
		}*/

		/* if($shiftclean1==$comp[0]['Companies']['am'])
				{
			if($chk){
					$rurl="/customer_Attendances/index";
					return $this->redirect("{$rurl}");
			}
		} */
		
			if($shiftclean==$comp[0]['Companies']['pm'])
			{
				if($chk4)
				{
					$rurl1="/customer_Attendances/index";
					return $this->redirect("{$rurl1}");
				}
			}
			if($shiftclean==$comp[0]['Companies']['am'])
			{
			if($chk3)
			{
				$rurl="/customer_Attendances/recent_attendance/?shift=pm";
				return $this->redirect("{$rurl}");
			}
			}
			if($shiftclean==null)
			{
				$url2 = "/customer_Attendances/index";
					return $this->redirect("{$url2}");
			}
			
		if ($this->request->is('post')) {
			$this->CustomerAttendance->create();
			if ($this->CustomerAttendance->save($this->request->data)) {
				$this->Session->setFlash(__('The customer attendance has been saved.'), 'default', array('class' => 'alert alert-success'));
				
				$rurl="/customer_Attendances/recent_attendance/?shift=am";
				$this->redirect("{$rurl}");
			} else {
				$this->Session->setFlash(__('The customer attendance could not be saved. Please, try again.'), 'default', array('class' => 'alert alert-danger'));
			}
		}
	
		$customers = $this->CustomerAttendance->Customer->find('list',array('conditions' => array('Customer.status_code_id' =>  '')));
		asort($customers);
		$this->set(compact('customers'));
		$this->loadModel('Customer');

		$dt = strtotime($date);

		$day = date("l", $dt);

		

		$gettodaycustomers=array(
			'conditions' => array("{$day}"."_"."{$shiftclean}" => 1,'Customer.status_code_id' =>  ''), //array of conditions
			'fields' => array('id'),
			'recursive' => 0
		);
		$expectedcustomers=$this->Customer->find('list',$gettodaycustomers);
		asort($expectedcustomers);
		//pr($expectedcustomers);
		$this->set('expectedcustomers',$expectedcustomers);
		$this->set('dateinurl',$dt);
		$this->set('shift',$shiftclean);
		$this->set('day',$day);

		$this->loadModel('Companies');
			$comp = $this->Companies->find('all');
		$this->set('comp',$comp);
		//pr($comp);
		}


	public function selectday()
	{
		$this->loadModel('Companies');
		$comp = $this->Companies->find('all');
		$this->set('comp',$comp);
		//pr($comp);
		//pr($shiftclean);
			/*	$date=date('M-d-Y');
			$shift=$_GET['shift'];

		$sh  = array($comp[0]['Companies']['shift']);
		$key     = array_search($shift,$sh);
		$shiftclean = $sh[$key]; //if not, first one will be set automatically. smart enuf :)
		//$both=$comp[0]['Companies']['shift'];
		$this->set('shiftclean',$shiftclean);
		//pr($shift);
			$chk=$this->CustomerAttendance->findAllByDateAndShift($date,'am');
			$chk1=$this->CustomerAttendance->findAllByDateAndShift($date,'pm');
		//	$chk2=$this->CustomerAttendance->findAllByDateAndShift($date,array('am','pm'));
			//pr($chk2);
			if($shiftclean=="pm")
				{
			if($chk1){
					$rurl1="/customer_Attendances/index";
					return $this->redirect("{$rurl1}");
			}
		}
		if($shiftclean=="am")
				{
			if($chk){
				$rurl="/customer_Attendances/index";
				return $this->redirect("{$rurl}");
			}
		} */

	}
/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		$this->set('title_for_layout', 'Edit Participants Attendance');
		if (!$this->CustomerAttendance->exists($id)) {
			throw new NotFoundException(__('Invalid customer attendance'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->CustomerAttendance->save($this->request->data)) {
				$this->Session->setFlash(__('The customer attendance has been saved.'), 'default', array('class' => 'alert alert-success'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The customer attendance could not be saved. Please, try again.'), 'default', array('class' => 'alert alert-danger'));
			}
		} else {
			$options = array('conditions' => array('CustomerAttendance.' . $this->CustomerAttendance->primaryKey => $id));
			//this sorts the selected array
			asort($options);
			$this->request->data = $this->CustomerAttendance->find('first', $options);

		}
		$customers = $this->CustomerAttendance->Customer->find('list');
		//this sorts the customer array
		asort($customers);
		$this->set(compact('customers'));
		
		$this->loadModel('Companies');
		$comp = $this->Companies->find('all');
		$this->set('comp',$comp);

		
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->CustomerAttendance->id = $id;
		if (!$this->CustomerAttendance->exists()) {
			throw new NotFoundException(__('Invalid customer attendance'));
		}
		$this->request->onlyAllow('post', 'delete');
		if ($this->CustomerAttendance->delete()) {
			$this->Session->setFlash(__('The customer attendance has been deleted.'), 'default', array('class' => 'alert alert-success'));
		} else {
			$this->Session->setFlash(__('The customer attendance could not be deleted. Please, try again.'), 'default', array('class' => 'alert alert-danger'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}