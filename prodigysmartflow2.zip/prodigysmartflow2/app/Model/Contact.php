<?php 

App::uses('AppModel', 'Model');


class Contact extends AppModel {
    public $useTable = false; 
}
?>