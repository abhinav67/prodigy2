<?php
App::uses('AppModel', 'Model');

class Reconciliation extends AppModel
{

public $useTable = false;

}