<?php
App::uses('AppModel', 'Model');

class Report extends AppModel {
    public $useTable = false; // This model uses a database table 'exmp'
}
?>