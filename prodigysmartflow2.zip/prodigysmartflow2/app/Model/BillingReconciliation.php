<?php
App::uses('AppModel', 'Model');

class BillingReconciliation extends AppModel
{

}

?>