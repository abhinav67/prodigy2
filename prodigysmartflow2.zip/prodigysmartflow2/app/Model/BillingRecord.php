<?php
App::uses('AppModel', 'Model');

class BillingRecord extends AppModel
{

}

?>